xstrap
======

X-Strap. The Skeleton for all Straps including (but not limited to) fbstrap, metrostrap, bootstrap, gstrap, droidstrap, istrap etc.