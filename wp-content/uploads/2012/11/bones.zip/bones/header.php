<!doctype html>  

<!--[if lt IE 7]><html <?php language_attributes(); ?> class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if (IE 7)&!(IEMobile)]><html <?php language_attributes(); ?> class="no-js lt-ie9 lt-ie8"><![endif]-->
<!--[if (IE 8)&!(IEMobile)]><html <?php language_attributes(); ?> class="no-js lt-ie9"><![endif]-->
<!--[if gt IE 8]><!--> <html <?php language_attributes(); ?> class="no-js"><!--<![endif]-->
	
	<head>
		<meta charset="utf-8">
		
		<title><?php //wp_title(''); ?></title>
		
		<!-- Google Chrome Frame for IE -->
		<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
		
		<!-- mobile meta (hooray!) -->
		<meta name="HandheldFriendly" content="True">
		<meta name="MobileOptimized" content="320">
		<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
		
		<!-- icons & favicons (for more: http://themble.com/support/adding-icons-favicons/) -->
		<link rel="shortcut icon" href="<?php echo get_template_directory_uri(); ?>/favicon.ico">
				<link rel="stylesheet/less" type="text/css" href="<?php bloginfo('template_directory'); ?>/bootstrap/less/bootstrap.less" />
				<link rel="stylesheet/less" type="text/css" href="<?php bloginfo('template_directory'); ?>/bootstrap/less/responsive.less" />
				<link rel="stylesheet/less" type="text/css" href="<?php bloginfo('template_directory'); ?>/less/layout.less" />
				<link rel="stylesheet/less" type="text/css" href="<?php bloginfo('template_directory'); ?>/less/header.less" />
				<link rel="stylesheet/less" type="text/css" href="<?php bloginfo('template_directory'); ?>/less/footer.less" />
  		<link rel="pingback" href="<?php bloginfo('pingback_url'); ?>">
  	<script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/less/less-1.3.0.min.js"></script>	
  	
		
		<!-- wordpress head functions -->
		<?php wp_head(); ?>
		<!-- end of wordpress head -->
			
		<!-- drop Google Analytics Here -->
		<!-- end analytics -->
		
	</head>
	
	<body <?php body_class(); ?>>
	
		
			
			
					
					<!-- to use a image just replace the bloginfo('name') with your img src and remove the surrounding <p> -->
					<!--<p id="logo" class="h1"> <a href="<?php echo home_url(); ?>" rel="nofollow"> <?php bloginfo('name'); ?></a></p>-->
					
					<!-- if you'd like to use the site description you can un-comment it below 
					<?php  bloginfo('description'); ?>-->
					<!--<ul class="thumbnails">
  <li class="span4">
    <div class="thumbnail">
      
    
<nav class="navbar pull-left">
	<img class="thumbnail pull-left" src="<?php bloginfo('template_directory');?>/images/RCorp_Logo.jpg" alt="logo">
	
    <div class="navbar-inner">-->
    	
    	<header class="header" role="banner">
			
				<div id="inner-header" class="wrap clearfix">
 <nav class="navbar">
  <div class="navbar-inner">
    <div class="container">
 
      <!-- .btn-navbar is used as the toggle for collapsed navbar content -->
      <a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </a>

      <!-- Be sure to leave the brand out there if you want it shown -->
      <a class="brand" href="#">Project name</a>
 
      <!-- Everything you want hidden at 940px or less, place within here -->
      <section class="nav-collapse collapse">
    	<ul class="nav">
          <?php
          global $pages;
          $pages=get_pages(array('sort_column'=>'menu__order','sort_order'=>'desc'));
          
          foreach($pages as $key)
          {
          ?>
		
             <li>                
	
	            <a href= "<?php echo get_page_link($key->ID); ?>"> <?php echo $key->post_title; ?> </a>
	
            </li>
            
        <?php
        }
        ?>


       </ul>
    </section>
    
      <form class="navbar-search pull-right">
         <input type="text" class="search-query" placeholder="Search">
      </form>
 </div>
 
    </div>
  </div>
</nav>	
				</div> <!-- end #inner-header -->
			
			</header> <!--end header -->
