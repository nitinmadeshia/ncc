<footer>
	   	    <img src="footer.fw.png" />
	   	    <div class="navbar navbar-inverse">
	   		<div class="navbar-inner">
	   			<ul class="nav">
	   				<li>
	   					<a href="#">Home </a>
	   				</li>
	   				<li>
	   					<a href="#"> Contact us</a>
	   				</li>
	   				<img  src="<?php bloginfo('template directory');?>/images/Flogo.fw.png" alt="footer" />
	   			</ul>
	   		 </div>
	   	     </div>
             </div> <!-- container ends-->
	     </footer>
	     <?php wp_footer(); ?>     
	 </body>
</html>