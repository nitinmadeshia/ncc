<!DOCTYPE html>
<html>
	<head>
		<title> <?php wp_title(''); ?> </title>
		<!--<link rel="stylesheet/less" type="text/css" href="bootstrap/less/bootstrap.less" />
		<script type="text/javascript" src="bootstrap/less/less-1.3.1.min.js"> </script>-->
		<link rel="stylesheet" type="text/css" href="<?php bloginfo('template directory'); ?>/bootstrap/less/bootstrap.css"/>
		<link rel="stylesheet" type="text/css" href="../dojo-release-1.8.1-src/dijit/themes/claro/claro.css"/>
		<script src="../dojo-release-1.8.1-src/dojo/dojo.js"></script>
		<script>
			require(["dojo/parser","dijit/form/TextBox","dijit/form/Button","dojo/domReady!"],function(parser,TextBox,Button)
			{
				parser.parse();
			});
		</script>
	</head>
	<body class="claro">
		<div class="container">
        <header>
		<div class="navbar">
		<!--navbar-inner starts-->
		<div class="navbar-inner"> 
			<img src="<?php bloginfo('template directory'); ?>/images/logo.fw.png" alt="logo"/>
	       	<!--<a class="brand" href="#"> </a>-->
	       	<ul class="nav pull-right">
	       		<?php
                global $pages;
                $pages=get_pages(array('sort_column'=>'menu__order','sort_order'=>'desc'));
          
                foreach($pages as $key)
                {
                ?>
                <li>
                	<a href= "<?php echo get_page_link($key->ID); ?>"> <?php echo $key->post_title; ?> </a>
                </li>
                <?php } ?>
             </ul>
         </div> 
	     <!--navbar-inner ends-->
		 </div>
		 </header>       