<?php get_header(); ?>
<!-- content starts-->
		<div class="wrapper">
			<img src="<?php bloginfo('template directory'); ?>/images/bg.fw.png" alt="background"/>
			<!-- left sidebar starts-->
			<div class="row">
				<div class="span3">
					<div class="lsidebar"> Important Information</div>
					<div class="lsidebar"> Publications</div>
				</div>
				<div class="span6">
					<!-- center part-->
					<div class="center"> Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat.
					Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim qui blandit praesent luptatum zzril delenit augue duis dolore te feugait nulla facilisi. Nam liber tempor cum soluta nobis eleifend option congue nihil imperdiet doming id quod mazim placerat facer possim assum. Typi non habent claritatem insitam; est usus legentis in iis qui facit eorum claritatem.
					</div>
	   	        </div>
	            <div class="span3">   	  
	   	       	    <!--right-sidebar starts-->
	   	       	    <div class="right-sidebar">
	   	       	    	<div class="triangle"> </div>
	   	       	    	<div class="formstrip">
	   	       	    		<span class="formstrip-text pull-right">Registered Members Login</span>
	   	       	    	</div>
	   	       	    	<!-- form starts-->
	   	    	        <label for="registrationid">Enter Registration Id </label>
	   	    	        <div data-dojo-type="dijit/form/TextBox"  id="registrationid"> </div>
	   	    	        <label for="password">Enter Password </label>
	   	    	        <div data-dojo-type="dijit/form/TextBox"  id="password"> </div>
	   	    	        <div data-dojo-type="dijit/form/Button"  data-dojo-props="label:'Submit','class':'btn btn-primary'"> </div>
	   	    	        <a href="#"> Password Help</a>
	   		            <!-- form ends-->
	   		            <div class="triangle"> </div>
	   		            <div class="formstrip">
	   		            	<span class="formstrip-text pull-right">First Time User Registration</span> </div>
	   	           </div>
	   	         </div>
	   	       </div>   
	   	  </div>
<?php get_footer(); ?>
